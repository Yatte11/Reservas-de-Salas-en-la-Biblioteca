# Documento de requisitos — Registro e inicio de sesión de estudiantes

## Introducción
Primer incremento (rama `feature/login`) del sistema de reserva de salas de la biblioteca. Permite que un estudiante cree una cuenta con su correo institucional, inicie y cierre sesión. Los requisitos provienen del documento de análisis de requisitos del equipo (RF-01 a RF-04, RF-06; RNF-01, RNF-02, RNF-05, RNF-06).

## Requisitos

### Requisito 1 — Registro de estudiante (US-01 · RF-01, RF-02, RNF-01, RNF-05)

**Historia de usuario:** Como estudiante de la universidad, quiero registrarme con mi correo institucional y código estudiantil para acceder al sistema de reservas de salas de la biblioteca.

#### Criterios de aceptación
1. CUANDO el estudiante envía el formulario con datos válidos y acepta el consentimiento de datos, ENTONCES el sistema DEBERÁ crear la cuenta y mostrar un mensaje de éxito.
2. CUANDO el correo no pertenece al dominio institucional, ENTONCES el sistema DEBERÁ mostrar «Debes usar tu correo institucional» y NO DEBERÁ crear la cuenta.
3. CUANDO el correo o el código estudiantil ya existe, ENTONCES el sistema DEBERÁ informar que ya está registrado sin revelar datos de otra persona.
4. CUANDO la contraseña tiene menos de 8 caracteres o no combina letras y números, ENTONCES el sistema DEBERÁ mostrar el requisito incumplido.
5. CUANDO el estudiante no acepta el consentimiento de tratamiento de datos, ENTONCES el sistema NO DEBERÁ crear la cuenta.
6. El sistema DEBERÁ almacenar la contraseña con hash bcrypt (factor de costo >= 10) y NUNCA en texto plano.

### Requisito 2 — Inicio de sesión (US-02 · RF-03, RNF-02, RNF-06)

**Historia de usuario:** Como estudiante registrado, quiero iniciar sesión con mi correo institucional y contraseña para gestionar mis reservas de forma personal y segura.

#### Criterios de aceptación
1. CUANDO el estudiante ingresa credenciales correctas, ENTONCES el sistema DEBERÁ darle acceso a su panel en <= 2 s (percentil 95) con 200 usuarios concurrentes.
2. CUANDO ingresa credenciales incorrectas, ENTONCES el sistema DEBERÁ mostrar «Correo o contraseña incorrectos» sin indicar cuál es el erróneo.
3. CUANDO transcurren 30 minutos de inactividad, ENTONCES el sistema DEBERÁ expirar la sesión y redirigir al inicio de sesión.

### Requisito 3 — Cierre de sesión (US-03 · RF-04)

**Historia de usuario:** Como estudiante con sesión iniciada, quiero cerrar mi sesión para proteger mi cuenta en computadores compartidos de la biblioteca.

#### Criterios de aceptación
1. CUANDO el estudiante pulsa «Cerrar sesión», ENTONCES el sistema DEBERÁ invalidar la sesión en el servidor y redirigir al inicio de sesión.
2. CUANDO el estudiante usa el botón «Atrás» del navegador tras cerrar sesión, ENTONCES el sistema NO DEBERÁ mostrar páginas protegidas.

### Requisito 4 — Bloqueo por intentos fallidos (US-05 · RF-06, RNF-01)

**Historia de usuario:** Como estudiante, quiero que mi cuenta se bloquee temporalmente tras varios intentos fallidos para evitar que otra persona adivine mi contraseña.

#### Criterios de aceptación
1. CUANDO hay 5 intentos fallidos consecutivos, ENTONCES el sistema DEBERÁ bloquear la cuenta durante 15 minutos y mostrar el tiempo restante.
2. CUANDO el estudiante inicia sesión correctamente antes del quinto fallo, ENTONCES el sistema DEBERÁ reiniciar el contador de fallos a cero.

## Fuera del alcance de esta rama
- US-04 Recuperación de contraseña (RF-05): requiere un servicio de correo; pendiente.
- Pruebas de carga (RNF-02), pruebas de usabilidad (RNF-03) y disponibilidad (RNF-04): requieren entorno de despliegue; pendientes.
