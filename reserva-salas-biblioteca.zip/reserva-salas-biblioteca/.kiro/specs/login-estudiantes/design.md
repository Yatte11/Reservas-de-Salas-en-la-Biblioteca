# Documento de diseño — Registro e inicio de sesión de estudiantes

## Visión general
Aplicación Node.js/Express que sirve una API JSON (`/api/auth/*`) y páginas estáticas. La autenticación usa sesiones del lado del servidor (cookie `sid`), de modo que el cierre de sesión invalida la sesión en el servidor (RF-04).

## Arquitectura
```
Navegador (public/*.html + js)
        │  fetch JSON
        ▼
Express (src/app.js)
  ├─ helmet (cabeceras de seguridad)
  ├─ express-session (cookie httpOnly, expiración por inactividad de 30 min)
  ├─ /api/auth  → src/routes/auth.js
  └─ /dashboard.html → requireAuth + Cache-Control: no-store
        │
        ▼
SQLite (src/db.js) — tabla students
```

## Endpoints
| Método | Ruta | Descripción | Respuestas |
|---|---|---|---|
| POST | /api/auth/register | Crea la cuenta (Requisito 1) | 201, 400 (errors por campo), 409 |
| POST | /api/auth/login | Inicia sesión (Requisitos 2 y 4) | 200, 401, 423 (bloqueada) |
| POST | /api/auth/logout | Destruye la sesión (Requisito 3) | 200 |
| GET | /api/auth/me | Datos del estudiante autenticado | 200, 401 |

## Modelo de datos — tabla `students`
| Campo | Tipo | Notas |
|---|---|---|
| id | INTEGER PK | autoincremental |
| full_name | TEXT | nombre completo |
| student_code | TEXT UNIQUE | código estudiantil |
| email | TEXT UNIQUE | correo institucional en minúsculas |
| password_hash | TEXT | bcrypt, costo >= 10 |
| consent_at | TEXT | fecha y hora del consentimiento (RNF-05) |
| failed_attempts | INTEGER | contador de fallos consecutivos (RF-06) |
| locked_until | INTEGER NULL | marca de tiempo (ms) hasta la que la cuenta está bloqueada |
| created_at | TEXT | fecha de creación |

## Decisiones de diseño
- **Mensaje de error genérico** en el login y comparación bcrypt de relleno cuando el correo no existe, para no revelar qué cuentas existen.
- **Regeneración del id de sesión** al autenticar, para prevenir fijación de sesión.
- **`rolling: true`** en la cookie: la expiración de 30 min se renueva con cada petición, por lo que mide inactividad (RNF-06).
- **`Cache-Control: no-store`** en la API y en las páginas protegidas, y recarga en el evento `pageshow` del cliente (criterio 3.2).
- **Dominio de correo y secreto de sesión** en variables de entorno (`INSTITUTIONAL_EMAIL_DOMAIN`, `SESSION_SECRET`).

## Limitaciones conocidas
- El almacén de sesiones por defecto de express-session está en memoria: las sesiones se pierden al reiniciar y no es adecuado para producción con varias instancias. Debe reemplazarse por un almacén persistente antes de desplegar.
- No hay protección CSRF adicional más allá de `SameSite=Lax` y el uso de JSON.

## Estrategia de pruebas
Pruebas automáticas con `node --test` y supertest (`tests/auth.test.js`) que verifican cada criterio de aceptación de los Requisitos 1 a 4, usando SQLite en memoria.
