# Stack técnico

- Node.js 20 o superior, Express 5, express-session, helmet.
- SQLite mediante better-sqlite3 (archivo en `data/`).
- Contraseñas con bcryptjs (factor de costo >= 10, RNF-01).
- Frontend: HTML, CSS y JavaScript sin framework (carpeta `public/`).
- Pruebas: `node --test` con supertest. Ejecutar con `npm test`.

## Reglas
- Nunca guardar ni registrar contraseñas en texto plano.
- Los mensajes de error de autenticación son genéricos (no indican si falló el correo o la contraseña).
- Los valores que dependen de la institución (dominio de correo, secreto de sesión) se leen de variables de entorno (`.env.example`).
