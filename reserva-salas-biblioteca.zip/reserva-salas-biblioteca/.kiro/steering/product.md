# Producto: Reserva de salas en la biblioteca

Aplicación web para que los estudiantes de la universidad consulten, reserven y cancelen salas de estudio de la biblioteca.

- Usuarios: estudiantes (autenticados con correo institucional) y administrador de la biblioteca.
- Rama actual: `feature/login` — registro e inicio de sesión de estudiantes (US-01, US-02, US-03; y RF-06 de US-05).
- Documento de análisis de requisitos: `docs/Analisis_Requisitos_IA_Reserva_Salas_Biblioteca.docx`.
