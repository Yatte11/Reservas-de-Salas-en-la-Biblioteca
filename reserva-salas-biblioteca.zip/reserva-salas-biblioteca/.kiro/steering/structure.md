# Estructura del repositorio

- `src/` — servidor: `app.js` (Express), `routes/auth.js`, `middleware/auth.js`, `validators.js`, `db.js`, `config.js`.
- `public/` — páginas y scripts del cliente.
- `tests/` — pruebas automáticas.
- `.kiro/specs/login-estudiantes/` — especificación (requirements, design, tasks).
- `docs/` — documentación del análisis de requisitos.

## Convención de commits
Conventional Commits, por ejemplo: `feat(login): ...`, `test(login): ...`, `docs: ...`.
