# Reserva de salas en la biblioteca

Sistema web para reservar salas de estudio de la biblioteca universitaria.

**Rama `feature/login`:** registro e inicio de sesión de estudiantes.

## Qué incluye esta rama
| Historia | Descripción | Estado |
|---|---|---|
| US-01 | Registro con correo institucional y código estudiantil | Implementada y probada |
| US-02 | Inicio de sesión (mensaje de error genérico, sesión de 30 min de inactividad) | Implementada y probada |
| US-03 | Cierre de sesión (invalida la sesión en el servidor) | Implementada y probada |
| US-05 / RF-06 | Bloqueo de 15 min tras 5 intentos fallidos | Implementada y probada |
| US-04 | Recuperación de contraseña por correo | Pendiente |
| US-06 en adelante | Consulta, reserva y cancelación de salas | Pendiente (siguientes sprints) |

## Requisitos previos
- Node.js 20 o superior

## Ejecutar
```bash
npm install
cp .env.example .env      # en Windows: copy .env.example .env
# Edita .env: define SESSION_SECRET y INSTITUTIONAL_EMAIL_DOMAIN (dominio real de tu universidad)
npm start
```
Abre http://localhost:3000

## Pruebas
```bash
npm test
```
Las pruebas verifican los criterios de aceptación de `.kiro/specs/login-estudiantes/requirements.md`.

## Estructura
```
.kiro/                 especificación y steering en formato Kiro
docs/                  documento de análisis de requisitos (Word)
public/                páginas y scripts del cliente
src/                   servidor Express (rutas, validaciones, base de datos)
tests/                 pruebas automáticas
```

## Uso con Kiro
La carpeta `.kiro/` contiene la especificación (`requirements.md`, `design.md`, `tasks.md`) y los archivos de steering con el formato de Kiro. Para trabajar con ella, abre esta carpeta del proyecto en Kiro.

## Subir a GitHub
1. Crea un repositorio vacío en GitHub (sin README ni .gitignore).
2. En esta carpeta ejecuta:
```bash
git init
git branch -M main
git add .
git commit -m "chore: estructura inicial del proyecto y documentación"
git remote add origin https://github.com/<TU_USUARIO>/<TU_REPOSITORIO>.git
git push -u origin main

git checkout -b feature/login
git commit --allow-empty -m "feat(login): registro e inicio de sesión de estudiantes"
git push -u origin feature/login
```
Si prefieres un historial de commits por historia, divide `git add` por carpetas y haz un commit por cada una (por ejemplo, los sugeridos en el documento Word, sección 0).

## Limitaciones conocidas
- Las sesiones se guardan en memoria; hay que usar un almacén persistente para producción.
- El dominio de correo de `.env.example` es solo un ejemplo: cámbialo.
