// Configuración centralizada. Los valores de negocio provienen de los requisitos
// (RF-06, RNF-01, RNF-06); lo que depende de la institución se lee de variables de entorno.
module.exports = function loadConfig(overrides = {}) {
  return {
    port: Number(process.env.PORT) || 3000,
    env: process.env.NODE_ENV || 'development',
    sessionSecret: process.env.SESSION_SECRET || 'solo-para-desarrollo',
    emailDomain: (process.env.INSTITUTIONAL_EMAIL_DOMAIN || 'example.edu').toLowerCase(),
    dbPath: process.env.DB_PATH || './data/biblioteca.db',
    bcryptCost: 10,                    // RNF-01: factor de costo >= 10
    sessionIdleMs: 30 * 60 * 1000,     // RNF-06: expira a los 30 min de inactividad
    maxFailedAttempts: 5,              // RF-06: 5 intentos fallidos consecutivos
    lockMs: 15 * 60 * 1000,            // RF-06: bloqueo de 15 minutos
    passwordMinLength: 8,              // US-01: mínimo 8, letras y números
    ...overrides,
  };
};
