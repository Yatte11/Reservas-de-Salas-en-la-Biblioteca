const express = require('express');
const bcrypt = require('bcryptjs');
const { validateRegistration } = require('../validators');
const { requireAuth, noStore } = require('../middleware/auth');

module.exports = function authRouter({ db, config }) {
  const router = express.Router();
  router.use(noStore);

  // Hash de relleno para igualar el tiempo de respuesta cuando el correo no existe.
  const dummyHash = bcrypt.hashSync('relleno-no-valido', config.bcryptCost);

  const findByEmail = db.prepare('SELECT * FROM students WHERE email = ?');
  const findDuplicate = db.prepare('SELECT id FROM students WHERE email = ? OR student_code = ?');
  const insertStudent = db.prepare(
    'INSERT INTO students (full_name, student_code, email, password_hash, consent_at) VALUES (?, ?, ?, ?, ?)'
  );
  const registerFailure = db.prepare('UPDATE students SET failed_attempts = ?, locked_until = ? WHERE id = ?');
  const resetFailures = db.prepare('UPDATE students SET failed_attempts = 0, locked_until = NULL WHERE id = ?');

  // US-01 · Registro de estudiante
  router.post('/register', async (req, res) => {
    const { errors, values } = validateRegistration(req.body || {}, config);
    if (Object.keys(errors).length) return res.status(400).json({ errors });

    if (findDuplicate.get(values.correo, values.codigo)) {
      // No se revela a quién pertenece el dato duplicado.
      return res.status(409).json({ error: 'El correo o el código estudiantil ya está registrado.' });
    }

    const hash = await bcrypt.hash(values.password, config.bcryptCost);
    insertStudent.run(values.nombre, values.codigo, values.correo, hash, new Date().toISOString());
    return res.status(201).json({ mensaje: 'Cuenta creada correctamente. Ya puedes iniciar sesión.' });
  });

  // US-02 · Inicio de sesión (+ RF-06 bloqueo por intentos fallidos)
  router.post('/login', async (req, res) => {
    const correo = String((req.body || {}).correo || '').trim().toLowerCase();
    const password = String((req.body || {}).password || '');
    const generic = { error: 'Correo o contraseña incorrectos.' };

    const student = findByEmail.get(correo);
    if (!student) {
      await bcrypt.compare(password, dummyHash);
      return res.status(401).json(generic);
    }

    const now = Date.now();
    if (student.locked_until && student.locked_until > now) {
      const minutos = Math.ceil((student.locked_until - now) / 60000);
      return res.status(423).json({
        error: `Cuenta bloqueada temporalmente por intentos fallidos. Intenta de nuevo en ${minutos} minuto(s).`,
        minutosRestantes: minutos,
      });
    }

    // Si el bloqueo ya venció, el contador parte de cero.
    const previous = student.locked_until && student.locked_until <= now ? 0 : student.failed_attempts;

    const ok = await bcrypt.compare(password, student.password_hash);
    if (!ok) {
      const attempts = previous + 1;
      const lockedUntil = attempts >= config.maxFailedAttempts ? now + config.lockMs : null;
      registerFailure.run(attempts, lockedUntil, student.id);
      return res.status(401).json(generic);
    }

    resetFailures.run(student.id);
    // Regenerar el id de sesión al autenticar (previene fijación de sesión).
    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: 'No se pudo iniciar la sesión.' });
      req.session.studentId = student.id;
      req.session.save(() => res.json({ nombre: student.full_name, correo: student.email }));
    });
  });

  // US-03 · Cierre de sesión (invalida la sesión en el servidor)
  router.post('/logout', (req, res) => {
    req.session.destroy(() => {
      res.clearCookie('sid');
      res.json({ mensaje: 'Sesión cerrada.' });
    });
  });

  router.get('/me', requireAuth, (req, res) => {
    const s = db.prepare('SELECT full_name, email, student_code FROM students WHERE id = ?').get(req.session.studentId);
    if (!s) return req.session.destroy(() => res.status(401).json({ error: 'No autenticado.' }));
    res.json({ nombre: s.full_name, correo: s.email, codigoEstudiantil: s.student_code });
  });

  return router;
};
