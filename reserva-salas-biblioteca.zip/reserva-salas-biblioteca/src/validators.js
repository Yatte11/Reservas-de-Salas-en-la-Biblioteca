// Validaciones del registro (US-01 / RF-01 / RF-02).
function validateRegistration(body, config) {
  const errors = {};
  const nombre = String(body.nombre || '').trim();
  const codigo = String(body.codigoEstudiantil || '').trim();
  const correo = String(body.correo || '').trim().toLowerCase();
  const password = String(body.password || '');

  if (nombre.length < 3 || nombre.length > 100) errors.nombre = 'Ingresa tu nombre completo (3 a 100 caracteres).';
  if (!/^[A-Za-z0-9-]{3,30}$/.test(codigo)) errors.codigoEstudiantil = 'El código estudiantil solo admite letras, números y guion (3 a 30 caracteres).';

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
    errors.correo = 'Ingresa un correo válido.';
  } else if (!correo.endsWith('@' + config.emailDomain)) {
    errors.correo = 'Debes usar tu correo institucional';
  }

  const passwordErrors = [];
  if (password.length < config.passwordMinLength) passwordErrors.push(`al menos ${config.passwordMinLength} caracteres`);
  if (!/[A-Za-z]/.test(password)) passwordErrors.push('al menos una letra');
  if (!/[0-9]/.test(password)) passwordErrors.push('al menos un número');
  if (passwordErrors.length) errors.password = 'La contraseña debe tener ' + passwordErrors.join(', ') + '.';

  if (body.consentimiento !== true) errors.consentimiento = 'Debes aceptar el tratamiento de tus datos personales.';

  return { errors, values: { nombre, codigo, correo, password } };
}

module.exports = { validateRegistration };
