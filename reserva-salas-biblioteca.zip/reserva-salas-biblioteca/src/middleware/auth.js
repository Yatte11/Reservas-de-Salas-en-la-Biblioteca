function requireAuth(req, res, next) {
  if (req.session && req.session.studentId) return next();
  if (req.originalUrl.startsWith('/api/')) return res.status(401).json({ error: 'No autenticado.' });
  return res.redirect('/login.html');
}

// Evita que el navegador muestre páginas protegidas desde caché al usar "Atrás" tras cerrar sesión.
function noStore(req, res, next) {
  res.set('Cache-Control', 'no-store');
  next();
}

module.exports = { requireAuth, noStore };
