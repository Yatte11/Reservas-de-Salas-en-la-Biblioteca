const path = require('path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const authRouter = require('./routes/auth');
const { requireAuth, noStore } = require('./middleware/auth');

function createApp({ db, config }) {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(express.json({ limit: '10kb' }));

  app.use(
    session({
      name: 'sid',
      secret: config.sessionSecret,
      resave: false,
      saveUninitialized: false,
      rolling: true, // la expiración se renueva con cada petición => 30 min de INACTIVIDAD
      cookie: {
        httpOnly: true,
        sameSite: 'lax',
        secure: config.env === 'production',
        maxAge: config.sessionIdleMs,
      },
    })
  );

  app.use('/api/auth', authRouter({ db, config }));

  // Página protegida: requiere sesión activa.
  app.get('/dashboard.html', noStore, requireAuth, (req, res) =>
    res.sendFile(path.join(__dirname, '..', 'public', 'dashboard.html'))
  );

  app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html' }));
  return app;
}

module.exports = { createApp };
