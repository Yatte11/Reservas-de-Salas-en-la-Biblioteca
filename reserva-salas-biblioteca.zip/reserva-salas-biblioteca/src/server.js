try { process.loadEnvFile && process.loadEnvFile(); } catch { /* .env opcional */ }

const loadConfig = require('./config');
const { openDb } = require('./db');
const { createApp } = require('./app');

const config = loadConfig();
if (config.env === 'production' && config.sessionSecret === 'solo-para-desarrollo') {
  console.error('Define SESSION_SECRET antes de ejecutar en producción.');
  process.exit(1);
}

const db = openDb(config.dbPath);
createApp({ db, config }).listen(config.port, () => {
  console.log(`Servidor listo en http://localhost:${config.port}`);
  console.log(`Dominio de correo institucional aceptado: @${config.emailDomain}`);
});
