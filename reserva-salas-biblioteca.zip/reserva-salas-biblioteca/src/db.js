const Database = require('better-sqlite3');

function openDb(dbPath) {
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.exec(`
    CREATE TABLE IF NOT EXISTS students (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name         TEXT    NOT NULL,
      student_code      TEXT    NOT NULL UNIQUE,
      email             TEXT    NOT NULL UNIQUE,
      password_hash     TEXT    NOT NULL,
      consent_at        TEXT    NOT NULL,
      failed_attempts   INTEGER NOT NULL DEFAULT 0,
      locked_until      INTEGER,
      created_at        TEXT    NOT NULL DEFAULT (datetime('now'))
    );
  `);
  return db;
}

module.exports = { openDb };
