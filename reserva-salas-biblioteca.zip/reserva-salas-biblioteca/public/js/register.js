const form = document.getElementById('form');
const msg = document.getElementById('msg');
const btn = document.getElementById('enviar');

function limpiar() {
  document.querySelectorAll('.field-error').forEach((e) => (e.textContent = ''));
  msg.className = 'msg';
  msg.textContent = '';
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  limpiar();
  btn.disabled = true;
  const datos = {
    nombre: form.nombre.value,
    codigoEstudiantil: form.codigoEstudiantil.value,
    correo: form.correo.value,
    password: form.password.value,
    consentimiento: form.consentimiento.checked,
  };
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos),
    });
    const json = await res.json();
    if (res.status === 201) {
      msg.className = 'msg ok';
      msg.textContent = json.mensaje;
      form.reset();
      setTimeout(() => (location.href = '/login.html'), 1500);
    } else if (json.errors) {
      for (const [campo, texto] of Object.entries(json.errors)) {
        const el = document.querySelector(`[data-for="${campo}"]`);
        if (el) el.textContent = texto;
      }
    } else {
      msg.className = 'msg error';
      msg.textContent = json.error || 'No se pudo completar el registro.';
    }
  } catch {
    msg.className = 'msg error';
    msg.textContent = 'No se pudo conectar con el servidor.';
  } finally {
    btn.disabled = false;
  }
});
