(async () => {
  const res = await fetch('/api/auth/me');
  if (!res.ok) return (location.href = '/login.html');
  const s = await res.json();
  document.getElementById('saludo').textContent = `Hola, ${s.nombre}`;
  document.getElementById('datos').textContent = `${s.correo} · Código: ${s.codigoEstudiantil}`;
})();

document.getElementById('logout').addEventListener('click', async () => {
  await fetch('/api/auth/logout', { method: 'POST' });
  location.replace('/login.html');
});

// Si el navegador restaura la página desde caché (botón "Atrás"), se vuelve a validar la sesión.
window.addEventListener('pageshow', (e) => { if (e.persisted) location.reload(); });
