const form = document.getElementById('form');
const msg = document.getElementById('msg');
const btn = document.getElementById('enviar');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  msg.className = 'msg';
  btn.disabled = true;
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ correo: form.correo.value, password: form.password.value }),
    });
    const json = await res.json();
    if (res.ok) {
      location.href = '/dashboard.html';
    } else {
      msg.className = 'msg error';
      msg.textContent = json.error || 'No se pudo iniciar sesión.';
    }
  } catch {
    msg.className = 'msg error';
    msg.textContent = 'No se pudo conectar con el servidor.';
  } finally {
    btn.disabled = false;
  }
});
