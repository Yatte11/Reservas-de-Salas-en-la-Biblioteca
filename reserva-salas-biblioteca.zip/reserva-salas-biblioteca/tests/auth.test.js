const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const { openDb } = require('../src/db');
const { createApp } = require('../src/app');
const loadConfig = require('../src/config');

const valido = {
  nombre: 'Ana Pérez Loor',
  codigoEstudiantil: 'EST-1001',
  correo: 'ana.perez@example.edu',
  password: 'Clave1234',
  consentimiento: true,
};

let db, app, config;
beforeEach(() => {
  config = loadConfig({ emailDomain: 'example.edu', bcryptCost: 4 }); // costo bajo solo para acelerar las pruebas
  db = openDb(':memory:');
  app = createApp({ db, config });
});

const registrar = (datos = valido) => request(app).post('/api/auth/register').send(datos);
const login = (agent, correo, password) => agent.post('/api/auth/login').send({ correo, password });

test('config: el costo de bcrypt por defecto cumple RNF-01 (>= 10)', () => {
  assert.ok(loadConfig().bcryptCost >= 10);
});

// ---------- US-01 ----------
test('US-01: registro válido crea la cuenta', async () => {
  const r = await registrar();
  assert.equal(r.status, 201);
});

test('US-01: la contraseña se guarda con hash bcrypt, nunca en texto plano', async () => {
  await registrar();
  const row = db.prepare('SELECT password_hash FROM students').get();
  assert.match(row.password_hash, /^\$2[aby]\$/);
  assert.notEqual(row.password_hash, valido.password);
});

test('US-01: correo fuera del dominio institucional se rechaza', async () => {
  const r = await registrar({ ...valido, correo: 'ana@gmail.com' });
  assert.equal(r.status, 400);
  assert.equal(r.body.errors.correo, 'Debes usar tu correo institucional');
  assert.equal(db.prepare('SELECT COUNT(*) c FROM students').get().c, 0);
});

test('US-01: correo o código duplicado se rechaza sin revelar datos', async () => {
  await registrar();
  const porCorreo = await registrar({ ...valido, codigoEstudiantil: 'EST-2002' });
  const porCodigo = await registrar({ ...valido, correo: 'otra@example.edu' });
  for (const r of [porCorreo, porCodigo]) {
    assert.equal(r.status, 409);
    assert.match(r.body.error, /ya está registrado/);
  }
});

test('US-01: contraseña débil se rechaza indicando el requisito incumplido', async () => {
  const corta = await registrar({ ...valido, password: 'ab1' });
  const sinNumero = await registrar({ ...valido, password: 'soloLetrasAqui' });
  assert.equal(corta.status, 400);
  assert.match(corta.body.errors.password, /al menos 8 caracteres/);
  assert.match(sinNumero.body.errors.password, /un número/);
});

test('US-01 / RNF-05: sin consentimiento de datos no se registra', async () => {
  const r = await registrar({ ...valido, consentimiento: false });
  assert.equal(r.status, 400);
  assert.ok(r.body.errors.consentimiento);
});

// ---------- US-02 ----------
test('US-02: credenciales correctas inician sesión', async () => {
  await registrar();
  const agent = request.agent(app);
  const r = await login(agent, valido.correo, valido.password);
  assert.equal(r.status, 200);
  assert.equal((await agent.get('/api/auth/me')).status, 200);
});

test('US-02: el correo no distingue mayúsculas/minúsculas', async () => {
  await registrar();
  const r = await login(request.agent(app), 'ANA.PEREZ@EXAMPLE.EDU', valido.password);
  assert.equal(r.status, 200);
});

test('US-02: credenciales incorrectas dan un mensaje genérico (no indica cuál falló)', async () => {
  await registrar();
  const malaClave = await login(request.agent(app), valido.correo, 'Incorrecta1');
  const noExiste = await login(request.agent(app), 'nadie@example.edu', 'Incorrecta1');
  assert.equal(malaClave.status, 401);
  assert.equal(noExiste.status, 401);
  assert.deepEqual(malaClave.body, noExiste.body);
});

test('US-02 / RNF-06: la cookie de sesión expira a los 30 min de inactividad', async () => {
  await registrar();
  const r = await login(request.agent(app), valido.correo, valido.password);
  const cookie = r.headers['set-cookie'].find((c) => c.startsWith('sid='));
  const expira = new Date(cookie.match(/Expires=([^;]+)/)[1]).getTime();
  const minutos = (expira - Date.now()) / 60000;
  assert.ok(minutos > 29 && minutos <= 30, `expira en ${minutos} min`);
  assert.match(cookie, /HttpOnly/);
});

test('US-02: sin sesión, la API y la página protegida no son accesibles', async () => {
  assert.equal((await request(app).get('/api/auth/me')).status, 401);
  const pagina = await request(app).get('/dashboard.html');
  assert.equal(pagina.status, 302);
  assert.equal(pagina.headers.location, '/login.html');
});

// ---------- US-03 ----------
test('US-03: cerrar sesión invalida la sesión en el servidor', async () => {
  await registrar();
  const agent = request.agent(app);
  await login(agent, valido.correo, valido.password);
  const cookieAntes = (await agent.get('/api/auth/me')).status;
  assert.equal(cookieAntes, 200);
  assert.equal((await agent.post('/api/auth/logout')).status, 200);
  assert.equal((await agent.get('/api/auth/me')).status, 401);
});

test('US-03: las páginas protegidas no se guardan en caché', async () => {
  await registrar();
  const agent = request.agent(app);
  await login(agent, valido.correo, valido.password);
  const r = await agent.get('/dashboard.html');
  assert.equal(r.status, 200);
  assert.match(r.headers['cache-control'], /no-store/);
});

// ---------- RF-06 (US-05) ----------
test('RF-06: tras 5 fallos consecutivos la cuenta se bloquea 15 min', async () => {
  await registrar();
  const agent = request.agent(app);
  for (let i = 0; i < 5; i++) assert.equal((await login(agent, valido.correo, 'Incorrecta1')).status, 401);
  const sexto = await login(agent, valido.correo, 'Incorrecta1');
  assert.equal(sexto.status, 423);
  assert.equal(sexto.body.minutosRestantes, 15);
  // incluso con la clave correcta sigue bloqueada
  assert.equal((await login(agent, valido.correo, valido.password)).status, 423);
});

test('RF-06: un inicio correcto antes del quinto fallo reinicia el contador', async () => {
  await registrar();
  const agent = request.agent(app);
  for (let i = 0; i < 4; i++) await login(agent, valido.correo, 'Incorrecta1');
  assert.equal((await login(agent, valido.correo, valido.password)).status, 200);
  for (let i = 0; i < 4; i++) assert.equal((await login(agent, valido.correo, 'Incorrecta1')).status, 401);
  assert.equal(db.prepare('SELECT failed_attempts a FROM students').get().a, 4);
});

test('RF-06: pasados los 15 min el bloqueo termina', async () => {
  await registrar();
  const agent = request.agent(app);
  for (let i = 0; i < 5; i++) await login(agent, valido.correo, 'Incorrecta1');
  db.prepare('UPDATE students SET locked_until = ?').run(Date.now() - 1000); // simula el paso del tiempo
  assert.equal((await login(agent, valido.correo, valido.password)).status, 200);
});
